package dao;

import java.util.List;

import bean.Emp;

public interface EmpDao {
   public List<Emp> selectEmp();
   public void addEmp(Emp emp);
   public Emp toupdate(int eid);
   public void update(Emp emp);
   public void deleteEmp(int eid);
}
