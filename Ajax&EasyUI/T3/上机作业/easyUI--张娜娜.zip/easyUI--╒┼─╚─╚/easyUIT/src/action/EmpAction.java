package action;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.alibaba.fastjson.JSON;



import com.google.gson.Gson;

import dao.EmpDao;
import dao.IEmpDaoImpl;
import bean.Emp;

public class EmpAction{
   private List<Emp> listemp;
   private EmpDao empDao=new IEmpDaoImpl();
   private Emp emp;
  
    private int eid;
	private String ename;
	private String address;
	private String email;
	private String phone;
   
   public String allEmp() throws IOException{
	   listemp=empDao.selectEmp();
	   HttpServletResponse response=ServletActionContext.getResponse();
	   response.setCharacterEncoding("UTF-8");
		PrintWriter out=response.getWriter();//输入
		Gson gso=new Gson();//创建一个gson实例;
	    String emp=gso.toJson(listemp);//json通过tojson()方法转化为字符串;
		out.write(emp);//直接写值
		
		out.flush();
		out.close();
	   return "list";   
   }
   public String addEmp() throws IOException{
	   HttpServletResponse response=ServletActionContext.getResponse();
		 response.setCharacterEncoding("UTF-8");//设置编码方式;
	     PrintWriter out=response.getWriter();
	   Emp emp=new Emp();
		   emp.setAddress(address);
		   emp.setEmail(email);
		   emp.setEname(ename);
		   emp.setPhone(phone);
		   emp.setEid(eid);
		   if(eid==0){
			   empDao.addEmp(emp);
			   int result=1;
			   out.write(result);
	   }else{
		     empDao.update(emp);
		     
	   }
         
		   
	     
	     return "add";
   }
   public String deleteEmp(){
	   empDao.deleteEmp(eid);
	   return "delete";
	   
   }

  public List<Emp> getListemp() {
	return listemp;
  }
  public void setListemp(List<Emp> listemp) {
	this.listemp = listemp;
  }
	public Emp getEmp() {
		return emp;
  }
	
	public void setEmp(Emp emp) {
		this.emp = emp;
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
}

