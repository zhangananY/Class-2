package dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import sessionFactory.HibernateSessionFactory;
import bean.Emp;



public class IEmpDaoImpl implements EmpDao {

	@Override
	public List<Emp> selectEmp() {	   
		Session session=HibernateSessionFactory.getSession();
		Transaction tt=session.beginTransaction();
		Query query=session.createQuery("from Emp");
		List<Emp> list=query.list();
		tt.commit();
		HibernateSessionFactory.closeSession();
		return list;
	}

	@Override
	public void addEmp(Emp emp) {
		Session session=HibernateSessionFactory.getSession();
		Transaction tt=session.beginTransaction();
		session.save(emp);
		tt.commit();
		HibernateSessionFactory.closeSession();
		
	}

	@Override
	public Emp toupdate(int eid) {
		Session session=HibernateSessionFactory.getSession();
		Transaction tt=session.beginTransaction();
		Emp emp=(Emp)session.get(Emp.class, eid);
		 tt.commit();
	     HibernateSessionFactory.closeSession();
		 return emp;
	}

	@Override
	public void update(Emp emp) {
		Session session=HibernateSessionFactory.getSession();
	     Transaction tx=session.beginTransaction();
	     Emp emp1=(Emp)session.get(Emp.class, emp.getEid());
	     emp1.setAddress(emp.getAddress());
	     emp1.setEname(emp.getEname());
	     emp1.setEmail(emp.getEmail());
	     emp1.setPhone(emp.getPhone());
	     session.update(emp1);
	     tx.commit();
	     HibernateSessionFactory.closeSession();
		
	}

	@Override
	public void deleteEmp(int eid) {
		 Session session=HibernateSessionFactory.getSession();
	     Transaction tx=session.beginTransaction();
	     Emp emp=(Emp)session.get(Emp.class, eid);
	     session.delete(emp);
	     tx.commit();
	     HibernateSessionFactory.closeSession();
	}
	

}
